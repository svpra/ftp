# virtual-m
Just yet another virtual machine

You can download it on http://ftp.svpra.ml/virtual-m.zip
